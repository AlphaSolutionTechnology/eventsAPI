package com.alphasolutions.eventAPI;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EventApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
